<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class List_order extends CI_Controller
{

	public function index()
	{	

		$this->load->view('list_order');
	}

	/*
	Get requst data from datatables.
	*/
	public function get()
	{
		$value = $this->input->get('status');
		if($value != ''){
			$result = $this->datatables->getData('order_header', array('order_header_ref','order_header_customers_name','order_header_customers_email','order_header_customers_telp','order_header_customers_address','order_header_customers_street', 'order_header_subtotal', 'order_header_delivery_fee', 'order_header_tax_total', 'order_header_total', 'order_header_note', 'order_header_status', 'order_header_date'), 'order_header_id', '','',array('order_header_status',$value));
		}else{
			$result = $this->datatables->getData('order_header', array('order_header_ref','order_header_customers_name','order_header_customers_email','order_header_customers_telp','order_header_customers_address','order_header_customers_street', 'order_header_subtotal', 'order_header_delivery_fee', 'order_header_tax_total', 'order_header_total', 'order_header_note', 'order_header_status', 'order_header_date'), 'order_header_id');
		}
		
		echo $result;
	}

    function get_order()
	{
		$value = $this->input->get('getRef');
		if($value != ''){
			$result = $this->datatables->getData('order_line', array('order_line_header_ref','order_line_category_name','order_line_name','order_line_price','order_line_disc','order_line_qty','order_line_subtotal','order_line_id'), 'order_line_id', '','',array('order_line_header_ref',$value));
			echo $result;
		}
	}
	

	 function insert_access()
	{
	
		$column = array('module_name','access_view','access_insert','access_update','access_delete');
		
		$Ids	 = $this->input->post('Ids');
		$no 	 = $this->input->post('columnPosition');
		$rowId 	 = $this->input->post('rowId');
		$group 	 = $this->input->post('group');
		$columns = $column[$no];
		$value 	 = $this->input->post('value');
		
		$this->load->model('group_model');
		
		if(!$Ids){
		$this->group_model->insert_access($rowId, $group, $columns, $value);
		}else{
		$this->group_model->update_access($Ids, $columns, $value);		
		}
	
	}
	
	 function update_status()
	{
		
		$data			= array();
		$status_data	= $this->input->post('status_data');
		$orders_id	 	= $this->input->post('orders_id');

		$data['order_header_status']	=	$status_data;
		
		$this->db->where('order_header_ref', $orders_id);
		$result = $this->db->update('order_header',$data);

	}
	
	// Get check update
	
	public function check()
	{
		$query = $this->db->query("SELECT COUNT(*) AS total FROM order_header WHERE order_header_status = 'orders'");
		$result = $query->result();
		echo $result[0]->total;	
	}
}

/* End of file category.php */
/* Location: ./application/controller/category.php */