<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Service extends CI_Controller
{
	//Get request menu
	public function get_menu()
	{
		$filter   = $this->input->post('data');
		$category = $this->input->post('category');
		
		$this->load->model('service_model');
		$query = $this->service_model->get_menu($filter,$category);
		
		header("Access-Control-Allow-Origin: *");
		header('Access-Control-Allow-Methods: GET, POST');
		echo json_encode($query);
	}
	
	//Get request menu detail
	public function get_menu_detail()
	{
		$id 	= $this->input->post('id');
		
		$this->load->model('service_model');
		$query 	= $this->service_model->get_menu_detail($id);
		
		header("Access-Control-Allow-Origin: *");
		header('Access-Control-Allow-Methods: GET, POST');
		echo json_encode($query);
	}
	
	public function get_promo_detail()
	{
		$id 	= $this->input->post('id');
		
		$this->load->model('service_model');
		$query 	= $this->service_model->get_promo_detail($id);
		
		header("Access-Control-Allow-Origin: *");
		header('Access-Control-Allow-Methods: GET, POST');
		echo json_encode($query);
	}
	
	//Get request category
	public function get_category()
	{		
		$this->load->model('service_model');
		$query = $this->service_model->get_category();

		header("Access-Control-Allow-Origin: *"); 
		header('Access-Control-Allow-Methods: GET, POST');		
		echo json_encode($query);
	}

	//Get request promo
	public function get_promo()
	{		
		$this->load->model('service_model');
		$query = $this->service_model->get_promo();

		header("Access-Control-Allow-Origin: *"); 
		header('Access-Control-Allow-Methods: GET, POST');		
		echo json_encode($query);
	}

	//Get request best seller
	public function get_best_seller()
	{		
		$this->load->model('service_model');
		$query = $this->service_model->get_best_seller();

		header("Access-Control-Allow-Origin: *"); 
		header('Access-Control-Allow-Methods: GET, POST');		
		echo json_encode($query);
	}
	
	//Get request historical orders
	public function get_historical_orders()
	{		
		$email 	= $this->input->post('email');
		$this->load->model('service_model');
		$query 	= $this->service_model->get_historical_orders($email);

		header("Access-Control-Allow-Origin: *"); 
		header('Access-Control-Allow-Methods: GET, POST');		
		echo json_encode($query);
	}
	
	//Get Register
	public function send_register()
	{

		header("Access-Control-Allow-Origin: *"); 
		header('Access-Control-Allow-Methods: GET, POST');
		
		$register_email 	= $this->input->post('email');
		$register_password 	= $this->input->post('password');
		$register_name 		= $this->input->post('name');
		$register_address 	= $this->input->post('address');
		$register_street 	= $this->input->post('street');
		$register_phone 	= $this->input->post('phone');
		$register_type 		= $this->input->post('type');
		
		
		$data = array(
			'register_email'=>$register_email ,
			'register_password'=>$register_password ,
			'register_name'=>$register_name,
			'register_address'=>$register_address,
			'register_street'=>$register_street,
			'register_phone'=>$register_phone,
			'register_type'=>$register_type
		);	
		
		$this->load->model('service_model');
		$query = $this->service_model->send_register($data);
		
		if($query)
			echo "Your registration complete!";
		else
			echo "Your register not complete!";
	}
	
	//Send message
	public function send_message()
	{

		header("Access-Control-Allow-Origin: *"); 
		header('Access-Control-Allow-Methods: GET, POST');
		
		$data 			 			=  array();
		$data['message_name'] 		= $this->input->post('name');
		$data['message_email']	 	= $this->input->post('email');
		$data['message_phone']		= $this->input->post('phone');
		$data['message_value'] 		= $this->input->post('message');
		
		$this->load->model('service_model');
		$query = $this->service_model->send_message($data);

		if($query)
			echo "Thanks for your message!";
		else
			echo "Your message not send!";
	}
	
	//Get message
	public function get_login()
	{
		$email 		= $this->input->post('email');
		$password 	= $this->input->post('password');
		
		$this->load->model('service_model');
		$query = $this->service_model->get_login($email, $password);
		
		header("Access-Control-Allow-Origin: *"); 
		header('Access-Control-Allow-Methods: GET, POST');
		
		echo json_encode($query);
	}
	
	//Get setting
	public function get_setting()
	{

		$this->load->model('service_model');
		$query = $this->service_model->get_setting();
		
		header("Access-Control-Allow-Origin: *"); 
		header('Access-Control-Allow-Methods: GET, POST');
		
		echo json_encode($query);
	}
	
	//Get opening hours
	public function get_opening()
	{

		$this->load->model('service_model');
		$query = $this->service_model->get_opening();
		
		header("Access-Control-Allow-Origin: *"); 
		header('Access-Control-Allow-Methods: GET, POST');
		
		echo json_encode($query);
		
	}	
	
	//Get checkout
	public function checkout()
	{

		header("Access-Control-Allow-Origin: *"); 
		header('Access-Control-Allow-Methods: GET, POST');
		
		$json_header = json_decode($this->input->get('header'), true);
		
			$data 	= array();
			$data['order_header_ref'] 				= $json_header["OrdersID"];
			$data['order_header_customers_name']	= $json_header["ordersToName"];
			$data['order_header_customers_email'] 	= $json_header["ordersToEmail"];
			$data['order_header_customers_telp'] 	= $json_header["ordersToTelp"];
			$data['order_header_customers_address'] = $json_header["ordersToAddress"];
			$data['order_header_customers_street'] 	= $json_header["ordersToStreet"];
			$data['order_header_delivery_fee'] 		= $json_header["ordersToDeliveryFee"];
			$data['order_header_tax'] 				= $json_header["ordersToTax"];
			$data['order_header_tax_total'] 		= $json_header["ordersToTaxTotal"];
			$data['order_header_subtotal'] 			= $json_header["ordersToSubTotal"];
			$data['order_header_total'] 			= $json_header["OrdersTotal"];
			$data['order_header_status'] 			= $json_header["ordersToStatus"];
			
			if(@$json_header["ordersToNote"] != null || @$json_header["ordersToNote"] != ''){
				$data['order_header_note'] 	 = $json_header["ordersToNote"];
			}
		
		$json_data = json_decode($this->input->get('line'), true);
		
		$data_line  =  array();
		
		foreach($json_data as $item) {
			
			$data_line['order_line_header_ref'] 	= $this->input->get('orderID');
			$data_line['order_line_menu_id'] 		= $item["id"];
			$data_line['order_line_category_name'] 	= $item["category"];
			$data_line['order_line_name'] 			= $item["name"];
			$data_line['order_line_image'] 			= $item["img"];
			$data_line['order_line_price'] 			= $item["price"];
			$data_line['order_line_disc'] 			= $item["disc"];
			$data_line['order_line_qty']			= $item["qty"];
			$data_line['order_line_subtotal'] 		= $item["subtotal"];
			
			$this->load->model('service_model');
			$query = $this->service_model->checkout_line($data_line);
		}
		
		$this->load->model('service_model');
		$query = $this->service_model->checkout_header($data);

		if($query)
			echo "Thanks for your orders!";
		else
			echo "Your orders not send!";
		
	}
}

/* End of file service.php */
/* Location: ./application/controller/service.php */