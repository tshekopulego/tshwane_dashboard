<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Message extends CI_Controller
{

	public function index()
	{	

		$this->load->view('message');
	}

	/*
	Get requst data from datatables.
	*/
	
	public function get()
	{
		// Get data message	
		$result = $this->datatables->getData('message', array('message_name','message_email','message_phone','message_value','message_timestamp','message_id'), 'message_id');
		echo $result;
	}

}

/* End of file message.php */
/* Location: ./application/controller/message.php */