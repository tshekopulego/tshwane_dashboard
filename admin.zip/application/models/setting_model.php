<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Setting_model extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}

	/*
	Action insert or update
	*/
	function insert($data,$data_id)
	{

		$this->db->where('setting_id', $data_id);
		$result = $this->db->update('setting',$data);
		
		return $result;

	}
	
	/*
	Remove 
	*/
	function remove($data_id)
	{
		
	 	return $this->db->delete('`table`', array('table_id' => $data_id));
				
	}
}