<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Service_model extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}

	function get_login($email, $password)
	{

		$query = $this->db->get_where('register', array('register_email' => $email,'register_password'=>$password),1);
		if ($query->num_rows() ==1)
		{
			$this->db->select('*');
			$this->db->from('register');
			$this->db->where('register_email',$email);
			
			$query = $this->db->get();
			$result = $query->result_array();

			return $result;
			
		}
		
		return 0;
	}
	
	function get_menu($data,$category)
	{
		
		$this->db->join('category', 'menu.menu_category_id = category.category_id','inner');
		$this->db->select('*');
        $this->db->from('menu');
		//$this->db->limit(5);
		if($data != ''){
			$this->db->like('menu_name',$data);
		}

		if($category != ''){
			$this->db->like('category_id',$category);
		}
		
		$query = $this->db->get();
		$result = $query->result_array();
		
		
		return $result;
	}

	function get_menu_detail($id)
	{
		
		$this->db->join('category', 'menu.menu_category_id = category.category_id','inner');
		$this->db->select('*');
        $this->db->from('menu');
		$this->db->where('menu_id',$id);

		$query = $this->db->get();
		$result = $query->result_array();
		
		
		return $result;
	}

	function get_promo_detail($id)
	{
		
		$this->db->select('*');
        $this->db->from('promo');
		$this->db->where('promo_id',$id);

		$query = $this->db->get();
		$result = $query->result_array();
		
		
		return $result;
	}
	
	function get_setting()
	{
		$this->db->select('*');
        $this->db->from('setting');
		
		$query = $this->db->get();
		$result = $query->result_array();

		return $result;
	}

	function get_opening()
	{
		$this->db->select('*');
        $this->db->from('opening_hours');
		
		$query = $this->db->get();
		$result = $query->result_array();

		return $result;
	}
	
	function get_category()
	{
		$this->db->select('category.category_id, category.category_name, category.category_img, COUNT(menu.menu_id) AS count,  category.category_desc');
        $this->db->from('category');

        $this->db->order_by('category_name', 'ASC');
		$this->db->join('menu', 'category.category_id = menu.menu_category_id','left');
        $this->db->group_by('category.category_id');
		 
		$query = $this->db->get();
		
		$result = $query->result_array();
		
		return $result;
	}

	function get_best_seller()
	{
		$this->db->select('order_line_menu_id, order_line_category_name, order_line_name, SUM(order_line_qty) AS qty, order_line_disc, order_line_image, order_line_price');
        $this->db->from('order_line');
		$this->db->group_by('order_line_menu_id');
        $this->db->order_by('SUM(order_line_qty)', 'DESC');
		$this->db->limit(12);
		$query = $this->db->get();
		
		$result = $query->result_array();
		
		return $result;
	}
	
	function get_promo()
	{
		$this->db->select('*');
        $this->db->from('promo');

        $this->db->order_by('promo_status', 'Aktif');
		 
		$query = $this->db->get();
		
		$result = $query->result_array();
		
		return $result;
	}

	function get_historical_orders($email)
	{
		$this->db->select('*');
        $this->db->from('order_header');
		$this->db->where('order_header_customers_email', $email);
        $this->db->order_by('order_header_date', 'DESC');
		 
		$query = $this->db->get();
		
		$result = $query->result_array();
		
		return $result;
	}
	
	function send_message($data)
	{
		
			$result = $this->db->insert('message',$data);
			
			return $result;
	}

	function send_register($data)
	{
		
			$result = $this->db->insert('register',$data);
			
			return $result;
	}
	
	function checkout_header($data)
	{
			$result = $this->db->insert('order_header',$data);
			
			return $result;
	}
	
	function checkout_line($data_line)
	{
			$this->db->insert('order_line',$data_line);
			
			return $result;
	}
}